PhytoScope: Concise Report for Annals of the New York Academy of Sciences

Selected main artwork: ONE Figure 1, also reused for the graphical abstract.
Four supporting figures and four editable supporting tables accompany the report.
The main figure preserves the approved overview geometry, with uppercase A-D labels.
All figure/table artwork: Arial Regular 7 pt; black text and black 0.5 pt strokes.

Body: 1280 words. Abstract: 150 words. References: 14.
Current journal instructions checked 26 October 2026; see 04_Submission_Documents.

01_Manuscript: editable Word, review PDF, Markdown.
02_Main_Figure: the sole main figure, PDF/vector SVG/600-dpi PNG, outlined SVG and legend.
03_Supporting_Information: extended methods, S1-S4 figures and separate editable S1-S4 tables.
04_Submission_Documents: cover letter and preparation/author-review record.
05_Reproducibility: selected public data, gold records, manifests, evidence and report source scripts.
06_Checks: word counts, reference metadata, actual PDF font/stroke audit, SHA256 inventory.

Author names, affiliations, ORCIDs, corresponding-author details, CRediT roles,
funding, conflicts, author approval/originality statements and archival DOI remain
explicit author-controlled fields. This draft has not been submitted.

Source/evidence snapshot: https://github.com/omixcore/phytoscope/tree/159ae0f79bd3681afc6c914db282c515190a3888
The manuscript-formatting changes postdate that snapshot and are versioned on dev.
To reproduce, check out the current dev report together with the pinned evidence;
follow the commands in Supporting Information and docs/non-model-portability-evidence.md.
The archive includes selected inputs, not full genomes/FASTQ archives. Public fetch
scripts verify source checksums. Arial font files are not redistributed.
Packaging checked document structure, all rendered Word pages, figure styles,
reference order and archive integrity; it did not rerun application/biological analyses.
Expression evidence concerns exact-release IDs from IC426787 reads against VRB3,
not genotype-matched expression biology or measured gains in user efficiency.

# Reproducibility

Source repository: https://github.com/omixcore/phytoscope
Pinned source commit: e98ab2fdc490869a82ae266985edde1fbff11574
Source commit URL: https://github.com/omixcore/phytoscope/tree/e98ab2fdc490869a82ae266985edde1fbff11574

This archive includes selected source manifests, the public expression matrix, sequence gold records, frozen structural validation reports, figure source files and scripts. Full genomes, full annotations and raw FASTQ reads are obtained with the source repository's fetch scripts and verified against the manifests. They are not duplicated in this manuscript archive.

Reproduce the application checks in a checkout of the pinned repository with Java 21. Follow `docs/non-model-portability-evidence.md` and the source Supplementary Information for the data-fetch, Salmon and test commands. To reproduce Figure 1, install Arial Regular, Inkscape and Pillow, then run `python manuscript/annals/figures/build_reference_style_figure.py` inside that checkout. The formatting scripts in this archive can postdate the application/evidence commit. Copy the supplied Figure_sources scripts into the pinned checkout at `manuscript/annals/figures/`, then run `build_figures.py`, `standardize_figures.py` and `build_supplementary_tables.py` there. The Word table formatter is included separately in Document_sources; retain the supplied styled Supplementary Information DOCX when exporting table-only figures. Run the scripts in the full checkout because their evidence paths are repository-relative. The file inventory pins all supplied formatting sources by SHA-256. Arial font files are not redistributed.

Packaging did not rerun biological analyses or the application test suite. It checked PDF and DOCX readability, selected figure numbering, file checksums and ZIP integrity.

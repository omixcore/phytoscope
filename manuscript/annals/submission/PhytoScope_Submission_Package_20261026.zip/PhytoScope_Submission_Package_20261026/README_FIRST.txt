PhytoScope manuscript materials
Target: Annals of the New York Academy of Sciences
Archive date: 20261026
Source commit: e98ab2fdc490869a82ae266985edde1fbff11574

01_Manuscript: manuscript Word file, review PDF and editable Markdown source.
02_Main_Figures: five individually numbered main figures in PDF/SVG/PNG; Figure 1 is the approved original-layout version. All figures include outlined SVG copies. Also includes the Figure 1 bilingual legend, formatting notes and a five-page combined review PDF.
03_Supplementary: Supplementary Information in Word, PDF and Markdown, plus four individual tables in PDF, editable SVG and outlined SVG.
04_Submission_Documents: cover letter, figure legends, checklist and explicit remaining author-review items.
05_Reproducibility: pinned source version, figure scripts/data, validation snapshots, public expression data and provenance manifests.
06_Package_checks: file inventory, SHA-256 checksums, actual-PDF font/line audits and packaging validation results.
Figures_and_Tables_review.pdf: combined nine-page review of all figures and tables.

Read 04_Submission_Documents/Items_to_complete.md before uploading. Author metadata/declarations remain placeholders; the manuscript has 20 references, so the previously requested 50–60-reference expansion is not complete. This is a packaged current draft, not an assertion that every submission requirement has been met.

Use only Figure_1 through Figure_5 as the selected main figures. Earlier alternate Figure 1 designs are not mixed into the upload figure set. The original overview SVG in the reproducibility folder is a build input.

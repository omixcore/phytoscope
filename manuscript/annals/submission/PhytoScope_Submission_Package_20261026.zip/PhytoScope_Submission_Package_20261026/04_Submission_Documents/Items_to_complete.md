# Author review items

This archive contains the current source materials, not a confirmation of journal acceptance or final submission readiness.

- Fill the author list, affiliations, corresponding author details and ORCIDs.
- Complete contributions, funding, acknowledgments and competing-interest declarations using author-verified information.
- Complete the originality, concurrent-submission and author-approval declarations in the cover letter.
- The manuscript currently has 20 references. The earlier requested 50–60-reference expansion is not completed in this archive. No new reference verification was performed during packaging.
- All five figures and four supplementary tables use Arial Regular 7 pt, black text and black 0.5 pt strokes. Figure 1 retains the approved original overview layout. Original data and panel layouts are retained; every arrow has a connected shaft and head.
- Check the manuscript's legacy Figure 1 caption together with the fuller panel-specific legend included beside the selected figure.
- Provide a permanent archival DOI and confirm source-data licensing as required.
- The checklist's journal-guideline snapshot is dated 2026-10-19; current instructions have not been rechecked during packaging.
- Expression validation supports exact-release identifier reconciliation for the tested rice-bean dataset; IC426787 reads and the VRB3 reference are different genotypes.

Current manuscript placeholders:

- [AFFILIATIONS]
- [AUTHOR NAMES IN FINAL ORDER]
- [AUTHOR TO COMPLETE using CRediT roles; verify each author's contribution and approval.]
- [AUTHOR TO COMPLETE: acknowledge data providers, institutional support, and contributors not meeting authorship criteria.]
- [AUTHOR TO COMPLETE: disclose relevant interests or state no competing interests only after confirmation by all authors.]
- [AUTHOR TO COMPLETE: funder names and grant numbers, or state that no specific funding was received if verified.]
- [AUTHOR TO COMPLETE: provide permanent archive DOI and confirm repository license and data licenses.]
- [NAME, EMAIL, POSTAL ADDRESS]
- [ORCID FOR EACH AUTHOR]
